<!DOCTYPE html>
<html lang="pt_br">
  <?php include ('_header.php')?>
    <body>
    <?php include ('_navbar.php')?>    
        <!-- Modal Search Start -->
        <div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content rounded-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Search by keyword</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center bg-primary">
                        <div class="input-group w-75 mx-auto d-flex">
                            <input type="search" class="form-control p-3" placeholder="keywords" aria-describedby="search-icon-1">
                            <span id="search-icon-1" class="btn bg-light border nput-group-text p-3"><i class="fa fa-search"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Search End -->


        <!-- Carousel Start -->
        <div class="header-carousel owl-carousel">
            <div class="header-carousel-item bg-natal">
                <div class="carousel-caption">
                    <div class="container">
                        <div class="row g-4 align-items-center">
                            <div class="col-lg-7 animated fadeInLeft">
                                <div class="text-sm-center text-md-start">
                                    <h4 class="text-white text-uppercase fw-bold mb-4">🎄 ConectaTI Solutions</h4>
                                    <h1 class="display-1 text-white mb-4">Tranquilidade em TI para este Natal</h1>
                                    <p class="mb-5 fs-5">Oferecemos serviços completos de tecnologia — desde a criação de sistemas até suporte técnico terceirizado — permitindo que sua empresa cresça com mais agilidade e menos preocupação.
                                    </p>
                                    <div class="d-flex justify-content-center justify-content-md-start flex-shrink-0 mb-4">
                                        <a class="btn btn-light rounded-pill py-3 px-4 px-md-5 me-2" href="#"><i class="fas fa-play-circle me-2"></i> Watch Video</a>
                                        <a class="btn btn-dark rounded-pill py-3 px-4 px-md-5 ms-2" href="#">Learn More</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5 animated fadeInRight">
                                <div class="calrousel-img" style="object-fit: cover;">
                                    <img src="img/carousel-2.png" class="img-fluid w-100" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-carousel-item bg-natal">
                <div class="carousel-caption">
                    <div class="container">
                        <div class="row gy-4 gy-lg-0 gx-0 gx-lg-5 align-items-center">
                            <div class="col-lg-5 animated fadeInLeft">
                                <div class="calrousel-img">
                                    <img src="img/carousel-3.png" class="img-fluid w-100" alt="">
                                </div>
                            </div>
                            <div class="col-lg-7 animated fadeInRight">
                                <div class="text-sm-center text-md-end">
                                    <h4 class="text-white text-uppercase fw-bold mb-4">🎄 ConectaTI Solutions</h4>
                                    <h1 class="display-1 text-white mb-4">Natal com Desconto em Serviços de TI</h1>
                                    <p class="mb-5 fs-5"> Suporte, terceirização e consultoria com condições especiais por tempo limitado.
                                    </p>
                                    <div class="d-flex justify-content-center justify-content-md-end flex-shrink-0 mb-4">
                                        <a class="btn btn-light rounded-pill py-3 px-4 px-md-5 me-2" href="#"><i class="fas fa-play-circle me-2"></i> Watch Video</a>
                                        <a class="btn btn-dark rounded-pill py-3 px-4 px-md-5 ms-2" href="#">Learn More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Carousel End -->

      <!-- Diferenciais Start -->
<div class="container-fluid feature bg-light py-5">
    <div class="container py-5">
        <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.2s" style="max-width: 800px;">
            <h4 class="text-primary">Por que escolher a ConectaTI</h4>
            <h1 class="display-4 mb-4">Muito mais que suporte técnico</h1>
            <p class="mb-0">
                Não entregamos apenas serviços de TI. Atuamos como parceiros estratégicos,
                ajudando empresas a crescer com tecnologia segura, eficiente e confiável.
            </p>
        </div>

        <div class="row g-4">
            <!-- Atendimento Próximo -->
            <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.2s">
                <div class="feature-item p-4 pt-0">
                    <div class="feature-icon p-4 mb-4">
                        <i class="fa fa-user-check fa-3x"></i>
                    </div>
                    <h4 class="mb-4">Atendimento Próximo</h4>
                    <p class="mb-4">
                        Relacionamento direto, comunicação clara e suporte humanizado,
                        sem burocracia e sem complicações.
                    </p>
                </div>
            </div>

            <!-- Prevenção e Monitoramento -->
            <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.4s">
                <div class="feature-item p-4 pt-0">
                    <div class="feature-icon p-4 mb-4">
                        <i class="fa fa-shield-alt fa-3x"></i>
                    </div>
                    <h4 class="mb-4">Prevenção de Falhas</h4>
                    <p class="mb-4">
                        Monitoramento contínuo e ações preventivas para evitar paradas,
                        perdas de dados e problemas inesperados.
                    </p>
                </div>
            </div>

            <!-- Soluções Sob Medida -->
            <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.6s">
                <div class="feature-item p-4 pt-0">
                    <div class="feature-icon p-4 mb-4">
                        <i class="fa fa-puzzle-piece fa-3x"></i>
                    </div>
                    <h4 class="mb-4">Soluções Sob Medida</h4>
                    <p class="mb-4">
                        Nada de pacotes engessados. Criamos soluções de TI alinhadas
                        à realidade e aos objetivos da sua empresa.
                    </p>
                </div>
            </div>

            <!-- Foco no Negócio -->
            <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.8s">
                <div class="feature-item p-4 pt-0">
                    <div class="feature-icon p-4 mb-4">
                        <i class="fa fa-chart-line fa-3x"></i>
                    </div>
                    <h4 class="mb-4">Foco em Resultados</h4>
                    <p class="mb-4">
                        A tecnologia trabalha para o seu negócio crescer, ganhar
                        eficiência, reduzir custos e aumentar a produtividade.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Diferenciais End -->


       <!-- About Start -->
<div class="container-fluid bg-light about pb-5">
    <div class="container pb-5">
        <div class="row g-5">
            <!-- Texto -->
            <div class="col-xl-6 wow fadeInLeft" data-wow-delay="0.2s">
                <div class="about-item-content bg-white rounded p-5 h-100">
                    <h4 class="text-primary">Sobre a ConectaTI Solutions</h4>
                    <h1 class="display-4 mb-4">
                        Soluções inteligentes em Tecnologia e Automação
                    </h1>

                    <p>
                        A ConectaTI Solutions é especializada em tecnologia corporativa,
                        oferecendo suporte, terceirização de TI e soluções sob medida
                        para empresas que buscam desempenho, segurança e eficiência.
                    </p>

                    <p>
                        Atuamos como um verdadeiro departamento de TI, cuidando da
                        infraestrutura, sistemas, redes, segurança e suporte técnico,
                        para que sua empresa foque no que realmente importa.
                    </p>

                    <p class="text-dark">
                        <i class="fa fa-check text-primary me-3"></i>
                        Suporte técnico contínuo e especializado
                    </p>
                    <p class="text-dark">
                        <i class="fa fa-check text-primary me-3"></i>
                        TI terceirizado com redução de custos
                    </p>
                    <p class="text-dark mb-4">
                        <i class="fa fa-check text-primary me-3"></i>
                        Soluções personalizadas para cada negócio
                    </p>

                    <a class="btn btn-primary rounded-pill py-3 px-5" href="#contato">
                        Falar com um especialista
                    </a>
                </div>
            </div>

            <!-- Imagem e contadores -->
            <div class="col-xl-6 wow fadeInRight" data-wow-delay="0.2s">
                <div class="bg-white rounded p-5 h-100">
                    <div class="row g-4 justify-content-center">
                        <div class="col-12">
                            <div class="rounded bg-light">
                                <img src="img/about-ti.png" class="img-fluid rounded w-100" alt="ConectaTI Solutions">
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="counter-item bg-light rounded p-3 h-100">
                                <div class="counter-counting">
                                    <span class="text-primary fs-2 fw-bold" data-toggle="counter-up">5</span>
                                    <span class="h1 fw-bold text-primary">+</span>
                                </div>
                                <h4 class="mb-0 text-dark">Anos de Experiência</h4>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="counter-item bg-light rounded p-3 h-100">
                                <div class="counter-counting">
                                    <span class="text-primary fs-2 fw-bold" data-toggle="counter-up">50</span>
                                    <span class="h1 fw-bold text-primary">+</span>
                                </div>
                                <h4 class="mb-0 text-dark">Projetos Entregues</h4>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="counter-item bg-light rounded p-3 h-100">
                                <div class="counter-counting">
                                    <span class="text-primary fs-2 fw-bold" data-toggle="counter-up">50</span>
                                    <span class="h1 fw-bold text-primary">+</span>
                                </div>
                                <h4 class="mb-0 text-dark">Clientes Atendidos</h4>
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <div class="counter-item bg-light rounded p-3 h-100">
                                <div class="counter-counting">
                                    <span class="text-primary fs-2 fw-bold" data-toggle="counter-up">100</span>
                                    <span class="h1 fw-bold text-primary">%</span>
                                </div>
                                <h4 class="mb-0 text-dark">Foco em Qualidade</h4>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- About End -->


     <!-- Service Start -->
<div class="container-fluid service py-5">
    <div class="container py-5">
        <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.2s" style="max-width: 800px;">
            <h4 class="text-primary">Nossos Serviços</h4>
            <h1 class="display-4 mb-4">Tecnologia completa para empresas</h1>
            <p class="mb-0">
                Soluções em TI pensadas para aumentar a produtividade, segurança
                e eficiência do seu negócio, com atendimento profissional e personalizado.
            </p>
        </div>

        <div class="row g-4 justify-content-center">
            <!-- Helpdesk e Suporte -->
            <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.2s">
                <div class="service-item">
                    <div class="service-img">
                  
                        <div class="service-icon p-3">
                            <i class="fa fa-headset fa-2x"></i>
                        </div>
                    </div>
                    <div class="service-content p-4">
                        <div class="service-content-inner">
                            <span class="d-inline-block h4 mb-4">Helpdesk e Suporte</span>
                            <p class="mb-4">
                                Atendimento técnico ágil para resolver problemas, manter sistemas
                                funcionando e garantir a produtividade da sua equipe.
                            </p>
                            <a class="btn btn-primary rounded-pill py-2 px-4" href="#contato">Saiba Mais</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TI Terceirizado -->
            <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.4s">
                <div class="service-item">
                    <div class="service-img">
                        <div class="service-icon p-3">
                            <i class="fa fa-network-wired fa-2x"></i>
                        </div>
                    </div>
                    <div class="service-content p-4">
                        <div class="service-content-inner">
                            <span class="d-inline-block h4 mb-4">TI Terceirizado</span>
                            <p class="mb-4">
                                Seu setor de TI completo, com gestão, monitoramento e suporte,
                                sem necessidade de equipe interna.
                            </p>
                            <a class="btn btn-primary rounded-pill py-2 px-4" href="#contato">Saiba Mais</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Migração de E-mails -->
            <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.6s">
                <div class="service-item">
                    <div class="service-img">
                        <div class="service-icon p-3">
                            <i class="fa fa-envelope fa-2x"></i>
                        </div>
                    </div>
                    <div class="service-content p-4">
                        <div class="service-content-inner">
                            <span class="d-inline-block h4 mb-4">Migração de E-mails</span>
                            <p class="mb-4">
                                Migração segura para Google Workspace ou Microsoft 365,
                                sem perda de dados e com mínima interrupção.
                            </p>
                            <a class="btn btn-primary rounded-pill py-2 px-4" href="#contato">Saiba Mais</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sites e Sistemas -->
            <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.8s">
                <div class="service-item">
                    <div class="service-img">
                        <div class="service-icon p-3">
                            <i class="fa fa-code fa-2x"></i>
                        </div>
                    </div>
                    <div class="service-content p-4">
                        <div class="service-content-inner">
                            <span class="d-inline-block h4 mb-4">Sistemas & Websites</span>
                            <p class="mb-4">
                                Desenvolvimento de sistemas personalizados e websites
                                profissionais integrados à realidade do seu negócio.
                            </p>
                            <a class="btn btn-primary rounded-pill py-2 px-4" href="#contato">Saiba Mais</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- CTA -->
            <div class="col-12 text-center wow fadeInUp" data-wow-delay="0.2s">
 
                <a class="btn btn-primary rounded-pill py-3 px-5" href="#contato">
                    Solicitar Orçamento
                </a>
            </div>
        </div>
    </div>
</div>
<!-- Service End -->

     <!-- FAQs Start -->
<div class="container-fluid faq-section bg-light py-5">
    <div class="container py-5">
        <div class="row g-5 align-items-center">

            <!-- FAQ -->
            <div class="col-xl-6 wow fadeInLeft" data-wow-delay="0.2s">
                <div class="h-100">
                    <div class="mb-5">
                        <h4 class="text-primary">Dúvidas Frequentes</h4>
                        <h1 class="display-4 mb-0">
                            Perguntas comuns sobre nossos serviços de TI
                        </h1>
                    </div>

                    <div class="accordion" id="accordionExample">

                        <!-- FAQ 1 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button border-0" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#collapseOne"
                                    aria-expanded="true" aria-controls="collapseOne">
                                    O que está incluso no suporte e TI terceirizado?
                                </button>
                            </h2>
                            <div id="collapseOne"
                                class="accordion-collapse collapse show active"
                                aria-labelledby="headingOne"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body rounded">
                                    O serviço inclui atendimento técnico, monitoramento,
                                    manutenção preventiva, gestão de rede, suporte a usuários
                                    e acompanhamento contínuo da infraestrutura de TI.
                                </div>
                            </div>
                        </div>

                        <!-- FAQ 2 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                    aria-expanded="false" aria-controls="collapseTwo">
                                    Vocês atendem empresas de qualquer porte?
                                </button>
                            </h2>
                            <div id="collapseTwo"
                                class="accordion-collapse collapse"
                                aria-labelledby="headingTwo"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Sim. Atendemos pequenas, médias e grandes empresas,
                                    oferecendo soluções personalizadas de acordo com o tamanho
                                    e a necessidade de cada negócio.
                                </div>
                            </div>
                        </div>

                        <!-- FAQ 3 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                    aria-expanded="false" aria-controls="collapseThree">
                                    Como funciona a migração de e-mails?
                                </button>
                            </h2>
                            <div id="collapseThree"
                                class="accordion-collapse collapse"
                                aria-labelledby="headingThree"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Realizamos a migração para Google Workspace ou Microsoft 365
                                    de forma segura, sem perda de dados e com mínima interrupção
                                    das atividades da empresa.
                                </div>
                            </div>
                        </div>

                        <!-- FAQ 4 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFour">
                                <button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#collapseFour"
                                    aria-expanded="false" aria-controls="collapseFour">
                                    Vocês desenvolvem sistemas e sites personalizados?
                                </button>
                            </h2>
                            <div id="collapseFour"
                                class="accordion-collapse collapse"
                                aria-labelledby="headingFour"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Sim. Criamos websites profissionais e sistemas sob medida,
                                    integrados a ERPs, automações e processos específicos de
                                    cada empresa.
                                </div>
                            </div>
                        </div>

                        <!-- FAQ 5 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFive">
                                <button class="accordion-button collapsed" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#collapseFive"
                                    aria-expanded="false" aria-controls="collapseFive">
                                    Como funciona o atendimento e o suporte?
                                </button>
                            </h2>
                            <div id="collapseFive"
                                class="accordion-collapse collapse"
                                aria-labelledby="headingFive"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    O atendimento ocorre por chamados, acesso remoto e,
                                    quando necessário, suporte presencial, sempre com foco
                                    em agilidade e resolução eficiente.
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Imagem -->
            <div class="col-xl-6 wow fadeInRight" data-wow-delay="0.4s">
                <img src="img/faq-ti.png" class="img-fluid w-100" alt="Dúvidas sobre serviços de TI">
            </div>

        </div>
    </div>
</div>
<!-- FAQs End -->
<?php include ('_footer.php')?>
    </body>

</html>